package main

import (
	"fmt"
	"io/ioutil" // Import the ioutil package
	"log"
	"math/rand"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/widget"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

func main() {
	myApp := app.New()

	// Load icon image into a byte slice
	iconBytes, err := ioutil.ReadFile("logo-min.png") // Change the path as necessary
	if err != nil {
		log.Fatal(err)
	}

	// Create a static resource from the byte slice
	iconResource := fyne.NewStaticResource("icon", iconBytes)
	myApp.SetIcon(iconResource)

	myWindow := myApp.NewWindow("WhatsSaaS Chat Demo")

	// Set window size
	myWindow.Resize(fyne.NewSize(600, 400))

	// MQTT configuration
	broker := "tcp://broker.hivemq.com:1883"
	// Generate a random number and update clientID
	rand.Seed(time.Now().UnixNano())
	randomNumber := rand.Intn(1000) // Generate a random number between 0 and 999
	clientID := fmt.Sprintf("whatssaas_client_%d", randomNumber)

	opts := mqtt.NewClientOptions().
		AddBroker(broker).
		SetClientID(clientID)

	c := mqtt.NewClient(opts)
	if token := c.Connect(); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}

	// Used to store received messages
	var messages []string

	// Create a list to display messages
	messageList := widget.NewList(
		func() int {
			return len(messages)
		},
		func() fyne.CanvasObject {
			return widget.NewLabel("") // Create an empty label for later filling
		},
		func(i int, obj fyne.CanvasObject) {
			obj.(*widget.Label).SetText(messages[len(messages)-1-i]) // Display messages in reverse order
		},
	)

	// Subscribe to the topic and set the callback function
	if token := c.Subscribe("fyne_topic", 0, func(client mqtt.Client, msg mqtt.Message) {
		// Get the current time
		currentTime := time.Now().Format("2006-01-02 15:04:05")
		// Add the received message to the message list, including clientID and sending time
		message := fmt.Sprintf("[%s] %s: %s", currentTime, clientID, string(msg.Payload()))
		messages = append(messages, message)
		// Update the list
		messageList.Refresh()
	}); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}

	// Input box
	messageEntry := widget.NewEntry()

	// Publish button
	publishButton := widget.NewButton("Send", func() {
		msg := messageEntry.Text // Get message from input box
		token := c.Publish("fyne_topic", 0, false, msg)
		token.Wait()
		messageEntry.SetText("") // Clear input box after publishing
	})

	// Create a scroll container, setting height to 200
	scrollContainer := container.NewScroll(messageList)
	scrollContainer.SetMinSize(fyne.NewSize(0, 200)) // Set minimum height to 200

	// Create the About content
	aboutContent := widget.NewLabel(
		"Author:WhatsSaaS - \n\nwww.whatssaas.com - Project Management, Task Manager, OKR, All-in-One Solution for Efficient Team Collaboration!\n\n" +
			"In the digital age, businesses need efficient collaboration tools to support their daily operations. Whatssaas is a new \nenterprise collaboration software that provides efficient collaboration and management tools for teams, making it easier for team members to share information and collaborate on tasks.\n\n" +
			"1. Project Management\n" +
			"Whatssaas' project management feature provides a powerful collaboration platform for teams. It allows you to create projects\n and assign tasks to each project to ensure that everyone knows what they need to do. Additionally, team members can communicate in real-time, share \n\n documents and files through Whatssaas. Furthermore, Whatssaas' project management feature provides a clear task list to help you track the progress of the team's work.\n\n" +
			"2. Enterprise File Management\n" +
			"Whatssaas' enterprise file management feature can help teams easily manage and share files. You can create folders in the \nenterprise file system and provide access permissions to team members to ensure file security. Additionally, Whatssaas supports fast upload and download of files, making it easy to \n\nshare documents and materials with team members.\n\n" +
			"3. Workflow Approval\n" +
			"We support fully customizable workflow approval, and customers can design 100% \nbusiness-compliant approval workflows by dragging and dropping.\n\n" +
			"4. Pure Intranet Operation\n" +
			"One of the highlights of Whatssaas is that it supports pure intranet operation, which means that your team's data will not be transmitted over a \npublic network, better protecting data security. Additionally, Whatssaas supports independent deployment, and you can run Whatssaas on your own server to gain higher control over your data.\n\n" +
			"In summary, Whatssaas is a highly practical enterprise collaboration software. Its project management, enterprise file management, and pure intranet \n\n operation features can help teams collaborate efficiently and improve work efficiency. Additionally, Whatssaas has the advantages of high cost-effectiveness, ease of use, and security reliability.\n\n If you are looking for an efficient enterprise collaboration software, try www.whatssaas.com.")

	// Create a container for the about content with a fixed width
	aboutContainer := container.NewVBox(
		container.NewMax(
			container.NewVBox(aboutContent),
		),
	)

	// Set a fixed width for the About content
	aboutContainer.Resize(fyne.NewSize(600, 0))

	// Create tabs
	tabs := container.NewAppTabs(
		container.NewTabItem("Messages", container.NewVBox(
			messageEntry,
			publishButton,
			scrollContainer,
		)),
		container.NewTabItem("About", aboutContainer),
	)

	// Set the content of the window to the tabs
	myWindow.SetContent(tabs)

	myWindow.ShowAndRun()
}
